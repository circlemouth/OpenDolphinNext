import { describe, expect, it } from 'vitest';

import {
  ORCA_SEND_ORDER_ENTITIES,
  normalizeOrderTestSubtype,
  resolveCanonicalOrderEntity,
  resolveOrderDockCategoryLabel,
  resolveOrderEntity,
  resolveOrderEntityDefaultClassMeta,
  resolveOrderEntityEtensuCategory,
  resolveOrderEntityLabel,
  resolveOrderEntityMasterSearchPolicy,
  resolveOrderEntityTestSubtypeConfig,
  resolveOrderEntityUiProfile,
  resolveOrderEntityValidationRule,
  resolveOrderGroupKeyByEntity,
} from '../orderCategoryRegistry';

describe('orderCategoryRegistry', () => {
  it('normalizes aliases and group keys consistently', () => {
    expect(resolveOrderEntityLabel('medOrder')).toBe('処方');
    expect(resolveOrderGroupKeyByEntity('medOrder')).toBe('prescription');
    expect(resolveOrderGroupKeyByEntity('laboTest')).toBe('test');
    expect(resolveOrderEntity('prescriptionOrder')).toBe('medOrder');
    expect(resolveOrderEntity('laboTest')).toBe('testOrder');
    expect(resolveOrderEntity(' laboTest ')).toBe('testOrder');
    expect(resolveCanonicalOrderEntity('laboTest')).toBe('testOrder');
    expect(resolveCanonicalOrderEntity('generalOrder')).toBe('treatmentOrder');
    expect(resolveCanonicalOrderEntity(' generalOrder ')).toBe('treatmentOrder');
    expect(resolveOrderGroupKeyByEntity('prescriptionOrder')).toBe('prescription');
    expect(resolveOrderDockCategoryLabel('charge')).toBe('算定');
  });

  it('returns entity specific ui, validation, and send metadata', () => {
    const medUi = resolveOrderEntityUiProfile('medOrder');
    const medRule = resolveOrderEntityValidationRule('medOrder');
    const injClass = resolveOrderEntityDefaultClassMeta('injectionOrder');

    expect(medUi.defaultMasterSearchType).toBe('drug');
    expect(medRule.requiresUsage).toBe(true);
    expect(resolveOrderEntityUiProfile('injectionOrder').supportsInjectionNoProcedure).toBe(false);
    expect(injClass?.classCode).toBe('310');
    expect(resolveOrderEntityEtensuCategory('radiologyOrder')).toBe('7');
    expect(ORCA_SEND_ORDER_ENTITIES).toContain('medOrder');
    expect(ORCA_SEND_ORDER_ENTITIES).toContain('injectionOrder');
    expect(ORCA_SEND_ORDER_ENTITIES).not.toContain('laboTest');
    expect(ORCA_SEND_ORDER_ENTITIES).not.toContain('generalOrder');
  });

  it('returns search policy aligned with each entity', () => {
    const injectionPolicy = resolveOrderEntityMasterSearchPolicy('injectionOrder');
    const treatmentPolicy = resolveOrderEntityMasterSearchPolicy('treatmentOrder');
    const testPolicy = resolveOrderEntityMasterSearchPolicy('testOrder');
    const chargePolicy = resolveOrderEntityMasterSearchPolicy('baseChargeOrder');
    const laboPolicy = resolveOrderEntityMasterSearchPolicy('laboTest');

    expect(injectionPolicy.masterSearchPresets.map((preset) => preset.type)).toEqual(['drug', 'etensu']);
    expect(injectionPolicy.defaultMasterSearchType).toBe('drug');
    expect(injectionPolicy.etensuCategory).toBe('3');
    expect(treatmentPolicy.etensuCategory).toBe('4');
    expect(testPolicy.etensuCategory).toBe('6');
    expect(chargePolicy.etensuCategory).toBe('1');
    expect(laboPolicy).toEqual(testPolicy);
  });

  it('exposes class 600 subtype config by entity', () => {
    const specimen = resolveOrderEntityTestSubtypeConfig('testOrder');
    const physiology = resolveOrderEntityTestSubtypeConfig('physiologyOrder');
    const bacteria = resolveOrderEntityTestSubtypeConfig('bacteriaOrder');

    expect(specimen?.readOnly).toBe(true);
    expect(specimen?.defaultValue).toBe('specimen');
    expect(physiology?.readOnly).toBe(true);
    expect(physiology?.defaultValue).toBe('physiology');
    expect(bacteria?.required).toBe(true);
    expect(bacteria?.options.map((option) => option.value)).toEqual(['culture', 'sensitivity']);
  });

  it('normalizes class 600 subtype by entity contract', () => {
    expect(normalizeOrderTestSubtype('testOrder', undefined)).toBe('specimen');
    expect(normalizeOrderTestSubtype('physiologyOrder', 'PHYSIOLOGY')).toBe('physiology');
    expect(normalizeOrderTestSubtype('bacteriaOrder', 'culture')).toBe('culture');
    expect(normalizeOrderTestSubtype('bacteriaOrder', 'invalid')).toBeUndefined();
  });
});
