import { http, HttpResponse } from 'msw';

import {
  buildAppointmentFixture,
  buildOfficialPatientNameSearchFixture,
  buildPatientListFixture,
  buildVisitListFixture,
  getOutpatientScenario,
  selectOutpatientScenario,
  updateOutpatientScenarioFlags,
  type OutpatientScenarioId,
} from '../fixtures/outpatient';
import { applyFaultDelay, parseFaultSpec, type FaultSpec } from '../utils/faultInjection';

const respond = <T extends Record<string, unknown>>(body: T) =>
  HttpResponse.json(body, {
    status: typeof body.status === 'number' ? (body.status as number) : 200,
    headers: {
      'x-run-id': String(body.runId ?? ''),
      'x-trace-id': String((body as any).traceId ?? ''),
      'x-data-source-transition': String(body.dataSourceTransition ?? ''),
      'x-cache-hit': String(body.cacheHit ?? ''),
      'x-missing-master': String(body.missingMaster ?? ''),
      'x-fallback-used': String((body as Record<string, unknown>).fallbackUsed ?? ''),
    },
  });

const applyRequestScenario = (request: Request) => {
  const headerScenario = request.headers.get('x-msw-scenario') as OutpatientScenarioId | null;
  if (headerScenario) {
    selectOutpatientScenario(headerScenario);
    return getOutpatientScenario();
  }

  const url = new URL(request.url);
  const queryScenario = (url.searchParams.get('scenario') as OutpatientScenarioId | null) ?? undefined;
  if (queryScenario) {
    selectOutpatientScenario(queryScenario);
    return getOutpatientScenario();
  }

  const cacheHitHeader = request.headers.get('x-msw-cache-hit');
  const missingMasterHeader = request.headers.get('x-msw-missing-master');
  const transitionHeader = request.headers.get('x-msw-transition');
  const fallbackUsedHeader = request.headers.get('x-msw-fallback-used');
  const runIdHeader = request.headers.get('x-msw-run-id');
  if (cacheHitHeader || missingMasterHeader || transitionHeader || fallbackUsedHeader || runIdHeader) {
    updateOutpatientScenarioFlags({
      cacheHit: cacheHitHeader === '1' || cacheHitHeader === 'true' ? true : cacheHitHeader === '0' ? false : undefined,
      missingMaster:
        missingMasterHeader === '1' || missingMasterHeader === 'true'
          ? true
          : missingMasterHeader === '0'
            ? false
            : undefined,
      dataSourceTransition: (transitionHeader as any) ?? undefined,
      fallbackUsed:
        fallbackUsedHeader === '1' || fallbackUsedHeader === 'true'
          ? true
          : fallbackUsedHeader === '0'
            ? false
            : undefined,
      runId: runIdHeader ? String(runIdHeader) : undefined,
    });
  }

  return getOutpatientScenario();
};

const hasNetworkFault = (fault: FaultSpec) =>
  fault.tokens.has('network') || fault.tokens.has('network-error') || fault.tokens.has('offline');

const resolveHttpFaultStatus = (fault: FaultSpec) => {
  if (fault.tokens.has('http-401') || fault.tokens.has('401')) return 401;
  if (fault.tokens.has('http-403') || fault.tokens.has('403')) return 403;
  if (fault.tokens.has('http-404') || fault.tokens.has('404')) return 404;
  return undefined;
};

export const outpatientHandlers = [
  http.post(/\/api\/orca\/official\/appointments\/list$/, async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      return respond({ ...(buildAppointmentFixture({ ...scenario.flags, status: httpFaultStatus }) as any), status: httpFaultStatus } as any);
    }
    if (fault.tokens.has('timeout')) {
      return respond({ ...(buildAppointmentFixture({ ...scenario.flags, status: 504 }) as any), status: 504 } as any);
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond({ ...(buildAppointmentFixture({ ...scenario.flags, status: 500 }) as any), status: 500 } as any);
    }
    if (fault.tokens.has('schema-mismatch')) {
      const mismatch = {
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        cacheHit: scenario.flags.cacheHit,
        missingMaster: scenario.flags.missingMaster,
        dataSourceTransition: scenario.flags.dataSourceTransition,
        fallbackUsed: scenario.flags.fallbackUsed,
        slots: 'schema-mismatch',
        reservations: { not: 'array' },
        apiResult: 'ERROR_SCHEMA_MISMATCH',
        apiResultMessage: 'MSW injected schema mismatch for orca/appointments/list',
        status: 200,
      } as any;
      return respond(mismatch);
    }
    return respond(buildAppointmentFixture(scenario.flags));
  }),
  http.post(/\/api\/orca\/official\/visits\/list$/, async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      return respond({ ...(buildVisitListFixture({ ...scenario.flags, status: httpFaultStatus }) as any), status: httpFaultStatus } as any);
    }
    if (fault.tokens.has('timeout')) {
      return respond({ ...(buildVisitListFixture({ ...scenario.flags, status: 504 }) as any), status: 504 } as any);
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond({ ...(buildVisitListFixture({ ...scenario.flags, status: 500 }) as any), status: 500 } as any);
    }
    if (fault.tokens.has('schema-mismatch')) {
      const mismatch = {
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        cacheHit: scenario.flags.cacheHit,
        missingMaster: scenario.flags.missingMaster,
        dataSourceTransition: scenario.flags.dataSourceTransition,
        fallbackUsed: scenario.flags.fallbackUsed,
        visits: 'schema-mismatch',
        apiResult: 'ERROR_SCHEMA_MISMATCH',
        apiResultMessage: 'MSW injected schema mismatch for orca/visits/list',
        status: 200,
      } as any;
      return respond(mismatch);
    }
    return respond(buildVisitListFixture(scenario.flags));
  }),
  http.post(/\/api\/orca\/official\/patients\/name-search$/, async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      return respond({
        ...buildOfficialPatientNameSearchFixture({ ...scenario.flags, status: httpFaultStatus, recordsReturned: 0 }),
        status: httpFaultStatus,
      } as any);
    }
    if (fault.tokens.has('timeout')) {
      return respond(buildOfficialPatientNameSearchFixture({ ...scenario.flags, status: 504, recordsReturned: 0 }));
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond(buildOfficialPatientNameSearchFixture({ ...scenario.flags, status: 500, recordsReturned: 0 }));
    }
    return respond(buildOfficialPatientNameSearchFixture(scenario.flags));
  }),
  http.post(/\/api\/local\/patients\/search$/, async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      const base = buildPatientListFixture({ ...scenario.flags, status: httpFaultStatus }, '/api/local/patients/search');
      if (httpFaultStatus === 404) {
        return respond({
          ...base,
          patients: [],
          recordsReturned: 0,
          auditEvent: base.auditEvent
            ? { ...base.auditEvent, details: { ...(base.auditEvent as any).details, recordsReturned: 0 } }
            : base.auditEvent,
        });
      }
      return respond(base);
    }
    if (fault.tokens.has('timeout')) {
      return respond(buildPatientListFixture({ ...scenario.flags, status: 504 }, '/api/local/patients/search'));
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond(buildPatientListFixture({ ...scenario.flags, status: 500 }, '/api/local/patients/search'));
    }
    if (fault.tokens.has('schema-mismatch')) {
      const mismatch = {
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        cacheHit: scenario.flags.cacheHit,
        missingMaster: scenario.flags.missingMaster,
        dataSourceTransition: scenario.flags.dataSourceTransition,
        fallbackUsed: scenario.flags.fallbackUsed,
        patients: 'schema-mismatch',
        apiResult: 'ERROR_SCHEMA_MISMATCH',
        apiResultMessage: 'MSW injected schema mismatch for patients/local-search',
        status: 200,
      } as any;
      return respond(mismatch);
    }
    return respond(buildPatientListFixture(scenario.flags, '/api/local/patients/search'));
  }),
  http.post(/\/api\/orca\/official\/patients\/import$/, async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      return respond({
        apiResult: '99',
        apiResultMessage: `HTTP fault injected (${httpFaultStatus})`,
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        requestId: `req-${scenario.flags.runId}`,
        facilityId: 'F-1',
        requestedCount: 0,
        fetchedCount: 0,
        createdCount: 0,
        updatedCount: 0,
        skippedCount: 0,
        errors: [],
        status: httpFaultStatus,
      });
    }
    if (fault.tokens.has('timeout')) {
      return respond({
        apiResult: '99',
        apiResultMessage: 'timeout',
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        requestId: `req-${scenario.flags.runId}`,
        facilityId: 'F-1',
        requestedCount: 0,
        fetchedCount: 0,
        createdCount: 0,
        updatedCount: 0,
        skippedCount: 0,
        errors: [],
        status: 504,
      });
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond({
        apiResult: '99',
        apiResultMessage: 'MSW injected 500 for patients/import',
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        requestId: `req-${scenario.flags.runId}`,
        facilityId: 'F-1',
        requestedCount: 0,
        fetchedCount: 0,
        createdCount: 0,
        updatedCount: 0,
        skippedCount: 0,
        errors: [],
        status: 500,
      });
    }

    const raw = (await request.json().catch(() => ({}))) as any;
    const patientIds: string[] = Array.isArray(raw?.patientIds) ? raw.patientIds : [];
    return respond({
      apiResult: '00',
      apiResultMessage: 'OK',
      runId: scenario.flags.runId,
      traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
      requestId: `req-${scenario.flags.runId}`,
      facilityId: 'F-1',
      requestedCount: patientIds.length,
      fetchedCount: patientIds.length,
      createdCount: patientIds.length,
      updatedCount: 0,
      skippedCount: 0,
      errors: [],
      status: 200,
    });
  }),
  http.post('/api/orca/official/patients/batch', async ({ request }) => {
    const scenario = applyRequestScenario(request);
    const raw = (await request.json().catch(() => ({}))) as any;
    const patientIds: string[] = Array.isArray(raw?.patientIds) ? raw.patientIds : [];
    return respond({
      apiResult: '00',
      apiResultMessage: 'OK',
      runId: scenario.flags.runId,
      traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
      routeNamespace: 'official',
      targetPatientCount: patientIds.length,
      noTargetPatientCount: 0,
      patients: patientIds.map((patientId) => ({
        summary: {
          patientId,
          wholeName: `患者 ${patientId}`,
          wholeNameKana: `カンジャ ${patientId}`,
          birthDate: '1980-01-01',
          sex: '1',
        },
        zipCode: '100-0001',
        address: '東京都千代田区',
        phoneNumber1: '0311112222',
      })),
      status: 200,
    });
  }),
  http.post('/api/orca/official/patientmodv2/outpatient/create', async ({ request }) => {
    const scenario = applyRequestScenario(request);
    const raw = (await request.json().catch(() => ({}))) as any;
    const patient = raw?.patient ?? {};
    const requestedPatientId = typeof patient.patientId === 'string' ? patient.patientId.trim() : '';
    const patientId = requestedPatientId && requestedPatientId !== '*' ? requestedPatientId : '000099';
    return respond({
      apiResult: '00',
      apiResultMessage: 'ORCA登録完了',
      runId: scenario.flags.runId,
      traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
      routeNamespace: 'official',
      patientDbId: 12,
      patientId,
      patient: {
        patientId,
        name: patient.wholeName ?? '患者 000099',
        kana: patient.wholeNameKana ?? 'カンジャ 000099',
        birthDate: patient.birthDate ?? '1980-01-01',
        sex: patient.sex ?? 'M',
        phone: patient.telephone ?? '0311112222',
        zip: patient.zipCode ?? '100-0001',
        address: patient.addressLine ?? '東京都千代田区',
      },
      status: 200,
    });
  }),
  http.post('/api/orca/official/patientmodv2/outpatient/update', async ({ request }) => {
    const scenario = applyRequestScenario(request);
    const raw = (await request.json().catch(() => ({}))) as any;
    const patient = raw?.patient ?? {};
    return respond({
      apiResult: '00',
      apiResultMessage: 'ORCA更新完了',
      runId: scenario.flags.runId,
      traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
      routeNamespace: 'official',
      patientDbId: 12,
      patientId: patient.patientId,
      patient: {
        patientId: patient.patientId,
        name: patient.wholeName ?? '患者 000001',
        kana: patient.wholeNameKana ?? 'カンジャ 000001',
        birthDate: patient.birthDate ?? '1980-01-01',
        sex: patient.sex ?? 'M',
        phone: patient.telephone ?? '0311112222',
        zip: patient.zipCode ?? '100-0001',
        address: patient.addressLine ?? '東京都千代田区',
      },
      status: 200,
    });
  }),
  http.post('/api/local/patients/mutation', async ({ request }) => {
    const fault = parseFaultSpec(request);
    const scenario = applyRequestScenario(request);
    await applyFaultDelay(fault);
    if (hasNetworkFault(fault)) {
      return HttpResponse.error();
    }
    const raw = (await request.json().catch(() => ({}))) as Record<string, unknown>;
    const patient = (raw.patient as Record<string, unknown> | undefined) ?? {};
    const operation = typeof raw.operation === 'string' ? raw.operation : 'update';
    const httpFaultStatus = resolveHttpFaultStatus(fault);
    if (httpFaultStatus) {
      return respond({
        apiResult: '99',
        apiResultMessage: `HTTP fault injected (${httpFaultStatus})`,
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        routeNamespace: 'local',
        status: httpFaultStatus,
      });
    }
    if (fault.tokens.has('timeout')) {
      return respond({
        apiResult: '99',
        apiResultMessage: 'timeout',
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        routeNamespace: 'local',
        status: 504,
      });
    }
    if (fault.tokens.has('http-500') || fault.tokens.has('500')) {
      return respond({
        apiResult: '99',
        apiResultMessage: 'MSW injected 500 for local patient mutation',
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        routeNamespace: 'local',
        status: 500,
      });
    }
    if (fault.tokens.has('schema-mismatch')) {
      const mismatch = {
        runId: scenario.flags.runId,
        traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
        routeNamespace: 'local',
        patientDbId: 'schema-mismatch',
        apiResult: 'ERROR_SCHEMA_MISMATCH',
        apiResultMessage: 'MSW injected schema mismatch for local patient mutation',
        status: 200,
      } as any;
      return respond(mismatch);
    }
    return respond({
      apiResult: '00',
      apiResultMessage: operation === 'create' ? '登録完了' : '更新完了',
      runId: scenario.flags.runId,
      traceId: scenario.flags.traceId ?? `trace-${scenario.flags.runId}`,
      routeNamespace: 'local',
      patientDbId: 12,
      patientId: typeof patient.patientId === 'string' ? patient.patientId : undefined,
      status: 200,
    });
  }),
];
