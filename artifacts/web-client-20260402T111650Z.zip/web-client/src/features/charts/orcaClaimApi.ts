import { httpFetch } from '../../libs/http/httpClient';
import { getObservabilityMeta } from '../../libs/observability/observability';

export type OrcaClaimSendResult = {
  ok: boolean;
  apiOk?: boolean;
  status: number;
  rawXml?: string;
  apiResult?: string;
  apiResultMessage?: string;
  informationDate?: string;
  informationTime?: string;
  invoiceNumber?: string;
  dataId?: string;
  medicalWarnings?: Array<{
    medicalWarning?: string;
    medicalWarningMessage?: string;
    medicalWarningPosition?: number;
    medicalWarningItemPosition?: number;
    medicalWarningCode?: string;
  }>;
  missingTags?: string[];
  runId?: string;
  traceId?: string;
  error?: string;
};

export const ORCA_MEDICALMODV2_PATH = '/api/orca/chart-support/medical-mod-v2';

export type MedicalModV2Medication = {
  code: string;
  name?: string;
  number?: string;
  unit?: string;
  genericFlg?: 'yes' | 'no';
};

export type MedicalModV2Information = {
  medicalClass: string;
  medicalClassName?: string;
  medicalClassNumber?: string;
  medications: MedicalModV2Medication[];
};

export type MedicalModV2RequestPayload = {
  patientId: string;
  performDate: string;
  departmentCode: string;
  physicianCode?: string;
  requestNumber?: string;
  medicalUid?: string;
  includeInitialConsultation?: boolean;
  medicalInformation?: MedicalModV2Information[];
};

export const buildMedicalModV2RequestXml = (params: MedicalModV2RequestPayload): MedicalModV2RequestPayload => params;

export async function postOrcaMedicalModV2Xml(
  payload: MedicalModV2RequestPayload,
  options: { classCode?: string; signal?: AbortSignal } = {},
): Promise<OrcaClaimSendResult> {
  const runId = getObservabilityMeta().runId;
  const response = await httpFetch(ORCA_MEDICALMODV2_PATH, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({
      ...payload,
      classCode: options.classCode,
    }),
    signal: options.signal,
  });
  const json = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  return {
    ok: response.ok && !(typeof json.error === 'string' && json.error.trim()),
    apiOk: typeof json.apiOk === 'boolean' ? json.apiOk : undefined,
    status: response.status,
    rawXml: undefined,
    apiResult: typeof json.apiResult === 'string' ? json.apiResult : undefined,
    apiResultMessage: typeof json.apiResultMessage === 'string' ? json.apiResultMessage : undefined,
    informationDate: typeof json.informationDate === 'string' ? json.informationDate : undefined,
    informationTime: typeof json.informationTime === 'string' ? json.informationTime : undefined,
    invoiceNumber: typeof json.invoiceNumber === 'string' ? json.invoiceNumber : undefined,
    dataId: typeof json.dataId === 'string' ? json.dataId : undefined,
    medicalWarnings: Array.isArray(json.medicalWarnings)
      ? (json.medicalWarnings as OrcaClaimSendResult['medicalWarnings'])
      : undefined,
    missingTags: undefined,
    runId: typeof json.runId === 'string' ? json.runId : getObservabilityMeta().runId ?? runId,
    traceId: typeof json.traceId === 'string' ? json.traceId : getObservabilityMeta().traceId,
    error: typeof json.error === 'string' ? json.error : undefined,
  };
}
