import type { ReactNode } from 'react';

import type { DataSourceTransition } from '../../libs/observability/types';

type PatientDisplay = {
  name: string;
  kana?: string;
  sex?: string;
  age?: string;
  birthDateEra?: string;
  birthDateIso?: string;
  zip?: string;
  address?: string;
  note?: string;
};

type ChartsPatientSummaryBarProps = {
  patientDisplay: PatientDisplay;
  patientId?: string;
  runId?: string;
  missingMaster?: boolean;
  fallbackUsed?: boolean;
  cacheHit?: boolean;
  dataSourceTransition?: DataSourceTransition;
  onStartEncounter?: () => void;
  onFinishEncounter?: () => void;
  onPauseEncounter?: () => void;
  onCloseChart?: () => void;
  onReloadChart?: () => void;
  encounterActionDisabled?: boolean;
  inlineActionBar?: ReactNode;
};

const normalizeValue = (value?: string): string | undefined => {
  if (!value) return undefined;
  if (value.trim() === '' || value === '—') return undefined;
  return value;
};

const normalizeMemo = (value?: string): string | undefined => {
  const safe = normalizeValue(value);
  if (!safe) return undefined;
  if (safe === 'メモなし') return undefined;
  return safe;
};

const normalizeZip = (zip?: string): string | undefined => {
  const safeZip = normalizeValue(zip);
  if (!safeZip) return undefined;
  return safeZip.startsWith('〒') ? safeZip : `〒${safeZip}`;
};

const formatSex = (sex?: string): string => {
  const safe = normalizeValue(sex);
  if (!safe) return '—';
  const normalized = safe.trim().toLowerCase();
  if (normalized === '1' || normalized === 'm' || normalized === 'male' || normalized === '男') return '男';
  if (normalized === '2' || normalized === 'f' || normalized === 'female' || normalized === '女') return '女';
  if (normalized === '9') return '不明';
  return safe;
};

export function ChartsPatientSummaryBar({
  patientDisplay,
  patientId,
  runId,
  missingMaster,
  fallbackUsed,
  cacheHit,
  dataSourceTransition,
  onStartEncounter,
  onCloseChart,
  onReloadChart,
  encounterActionDisabled = false,
  inlineActionBar,
}: ChartsPatientSummaryBarProps) {
  const displayName = normalizeValue(patientDisplay.name) ?? '患者未選択';
  const kana = normalizeValue(patientDisplay.kana);
  const sex = formatSex(patientDisplay.sex);
  const age = normalizeValue(patientDisplay.age) ?? '—';
  const birthEra = normalizeValue(patientDisplay.birthDateEra);
  const birthIso = normalizeValue(patientDisplay.birthDateIso);
  const birthDate = birthIso ?? birthEra ?? '—';
  const zip = normalizeZip(patientDisplay.zip);
  const address = normalizeValue(patientDisplay.address);
  const memo = normalizeMemo(patientDisplay.note);
  const hasMemo = Boolean(memo);
  const hasAddressMeta = Boolean(zip || address);

  return (
    <div
      className="charts-patient-summary"
      data-run-id={runId}
      data-missing-master={String(missingMaster ?? false)}
      data-cache-hit={String(cacheHit ?? false)}
      data-fallback-used={String(fallbackUsed ?? false)}
      data-source-transition={dataSourceTransition}
    >
      <div className="charts-patient-summary__layout" data-has-memo={hasMemo ? 'true' : 'false'}>
        <div className="charts-patient-summary__left">
          <div className="charts-patient-summary__primary-actions" role="group" aria-label="カルテ操作">
            <button
              type="button"
              className="charts-patient-summary__primary-action charts-patient-summary__primary-action--start"
              onClick={onStartEncounter}
              disabled={encounterActionDisabled || !onStartEncounter}
            >
              診察開始
            </button>
            <button
              type="button"
              className="charts-patient-summary__primary-action charts-patient-summary__primary-action--reload"
              onClick={onReloadChart}
              disabled={encounterActionDisabled || !onReloadChart}
            >
              更新
            </button>
            <button
              type="button"
              className="charts-patient-summary__primary-action charts-patient-summary__primary-action--close"
              onClick={onCloseChart}
              disabled={!onCloseChart}
            >
              閉じる
            </button>
          </div>

          <section className="charts-patient-summary__identity" aria-label="患者基本情報">
            <div className="charts-patient-summary__meta-line">
              <span className="charts-patient-summary__meta-pair">
                <span className="charts-patient-summary__meta-key">診察券番号</span>
                <span className="charts-patient-summary__meta-inline-value">{normalizeValue(patientId) ?? '—'}</span>
              </span>
              <span className="charts-patient-summary__meta-pair">
                <span className="charts-patient-summary__meta-key">年齢</span>
                <span className="charts-patient-summary__meta-inline-value">{age}</span>
              </span>
              <span className="charts-patient-summary__meta-pair">
                <span className="charts-patient-summary__meta-key">性別</span>
                <span className="charts-patient-summary__meta-inline-value">{sex}</span>
              </span>
              <span className="charts-patient-summary__meta-pair">
                <span className="charts-patient-summary__meta-key">生年月日</span>
                <span className="charts-patient-summary__meta-inline-value">{birthDate}</span>
              </span>
            </div>
            <p className="charts-patient-summary__kana">{kana ?? '—'}</p>
            <h2 className="charts-patient-summary__name">{displayName}</h2>
            {hasAddressMeta ? (
              <details className="charts-patient-summary__extra">
                <summary className="charts-patient-summary__extra-summary">詳細</summary>
                <div className="charts-patient-summary__extra-body">
                  {zip ? <p className="charts-patient-summary__address">{zip}</p> : null}
                  {address ? <p className="charts-patient-summary__address">{address}</p> : null}
                </div>
              </details>
            ) : null}
          </section>
        </div>

        {hasMemo ? (
          <section className="charts-patient-summary__memo-panel" aria-label="患者メモ">
            <h2 className="charts-patient-summary__memo-title">患者メモ</h2>
            <p className="charts-patient-summary__memo-body">{memo}</p>
          </section>
        ) : null}
      </div>

      {inlineActionBar ? <div className="charts-patient-summary__inline-actionbar">{inlineActionBar}</div> : null}
    </div>
  );
}
