# OpenDolphin WebClient remaining follow-up package 2026-04-17

## Historical status

This package is a historical planning package. Stale `PASS`, `latest worker report`, `pass 済み`, `already closed`, and completion language in this directory is not current evidence.

Current source of truth is:

1. `docs/implementation/opendolphin-postfix-static-remediation-20260418/08_static_exit_report.md`
2. `docs/contracts/orca-route-taxonomy.md`
3. `docs/contracts/orca-connection.md`
4. `docs/runbooks/release-validation.md`
5. `docs/releases/orca-remediation-cutover.md`

The 2026-04-18 static report includes accepted static test logs under `docs/implementation/opendolphin-postfix-static-remediation-20260418/test-logs/`. It does not claim live ORCA success. `runtime-ready-smoke` is recorded as an environment blocker when `127.0.0.1:9080` was not running, and `qa-acceptmodv2-weborca.mjs` / `qa-fullflow-weborca.mjs` were not run.

## 目的
この package は **planning-only** の統合物です。Codex 実装担当は、この package と repo 内の `source / tests / docs / notes / route / DTO / QA script` だけを参照して着手してください。
この package 自体は **コード変更、コミット、PR 作成を含みません**。
ただし、残タスクの実装・再検証・release gate handoff までを追加判断なしで開始できる粒度に固定しています。

## 正本の優先順位
1. current repo truth: `source / tests / docs / notes / route / DTO / QA script`
2. recovery plan: 追加設計候補
3. prompt / checklist / runbook / QA note
4. この package の fixed decision

repo truth と recovery plan が衝突した場合は repo truth を優先します。
repo に証拠がないものは **unknown** とし、gate + fail-close fallback を残しています。

## 固定前提
- 3 ペイン責務固定
- patient context 非永続
- `finish` と `send` の分離
- right rail chooser-only
- `送信済` と `会計済み` の非統合
- `send success != paid`
- generic bottom navigation の新規導入禁止
- 重要情報を disclosure に隠さない
- 1 画面 1 primary
- unknown は gate として残し、fail-close fallback を添える

## 読む順番
1. `00_MANAGER_DOCSET.yaml`
2. `00_MANAGER_PROMPT.md`
3. `01_WORKPLAN.md`
4. `10_CLAIM_SEND_CACHE_STORAGE_DOCSET.yaml`
5. `10_CLAIM_SEND_CACHE_STORAGE_PROMPT.md`
6. `20_CHARTS_CORRECTION_NOTE_DOCSET.yaml`
7. `20_CHARTS_CORRECTION_NOTE_PROMPT.md`
8. `30_POST_FIX_RELEASE_GATE_DOCSET.yaml`
9. `30_POST_FIX_RELEASE_GATE_RUNBOOK.md`
10. `31_MANUAL_QA_REENTRY_DOCSET.yaml`
11. `31_MANUAL_QA_REENTRY_CHECKLIST.md`
12. `32_ORCA_LIVE_QA_REENTRY_DOCSET.yaml`
13. `32_ORCA_LIVE_QA_REENTRY_CHECKLIST.md`
14. `40_CHATGPT_PROMPT_NOTE_VISIBILITY.md`
15. `41_CHATGPT_PROMPT_CACHE_STORAGE_CONTRACT.md`
16. `50_RELEASE_GATE_CHECKLIST.md`

## package の使い方
- `00_MANAGER_DOCSET.yaml` を全体の前提とする
- 各 task の docset にある acceptance と required_tests をセットで扱う
- `docs/web-client/ux/dads_app_ui_design_rules_20260411.md` を UI reference として参照する
- build artifacts / logs / screenshots / generated output は repo truth 判定に使わない

## package 外でやらないこと
- 外部サイト参照
- repo に証拠がない route/state/schema/copy の推測補完
- TODO 追加
- 暫定 shim 追加
- format-only 変更
- 後方互換維持のための unsafe workaround
