# Server modernization overview

この文書は `server-modernized` の現行境界を短く把握するための summary です。

## 入口
- 現行ハブ: [../managerdocs/README.md](../managerdocs/README.md)
- 実装モジュール: [`server-modernized/pom.xml`](../../server-modernized/pom.xml)
- 契約索引: [../README.md](../README.md)

## 現行の責務境界
- `server-modernized/` が Jakarta EE 10 ベースの現行実装
- `web-client/` はその public contract に合わせる
- `docs/contracts/` は runtime / health / ORCA / attachment の public contract を置く
- `docs/runbooks/` は release / validation の live 手順を置く
- `docs/operations/ORCA_CERTIFICATION_ONLY.md` は WebORCA Trial の接続確認手順を置く
- server 本体の永続化は外部 PostgreSQL 前提で進める
- 添付と画像の外部保存は `ATTACHMENT_STORAGE_MODE=s3` の S3 互換 object storage 前提で進める

## モジュール境界
- `domain`: 業務ルールと値オブジェクト
- `api-contract`: 公開 DTO、error contract、enum
- `persistence`: entity、query、migration 接続
- `reporting`: 帳票、署名、出力形式
- `server-modernized`: REST resource、認証/認可、ORCA 接続、worker 公開面

## route taxonomy
- official ORCA bridge は `/api/orca/official/*` を使う
- master-backed read API は `/api/orca/master/*` を使う
- local-only wrapper / local projection / local chart mutation は `/api/local/*` を使う
- `/api/orca/*` に local-only schema を混在させない

## まず見るもの
- `docs/contracts/runtime-config.md`
- `docs/contracts/health-endpoints.md`
- `docs/contracts/orca-connection.md`
- `docs/contracts/orca-master-api.md`
- `docs/contracts/document-integrity.md`
- `docs/contracts/patient-images.md`
- `docs/runbooks/release-validation.md`
- `docs/releases/orca-remediation-cutover.md`

## release gate
```bash
cd web-client && npm run ci
mvn -f pom.server-modernized.xml -pl server-modernized -am -Pstatic-analysis verify
cd web-client && node scripts/runtime-ready-smoke.mjs
```

## business-critical flows
- 認証と session 失効は server 側で統一し、権限変更や認証状態変更後は古い session を残さない。
- 受付からカルテへ渡すキーは `scheduleKey` / `encounterKey` を正本とし、client 推測値や旧受付 ID を route authority にしない。
- ORCA 接続は施設別設定と allowlist で解決し、任意 URL 接続や implicit fallback を許容しない。
- official patient mutation は create / update / import を別 route / 別 DTO で分離し、create は `patientmodv2 class=01`、update は `patientmodv2 class=02`、import は `patientlst2v2` / `patientgetv2` 系の canonical re-fetch + local sync を前提にする。
- 添付、患者画像、文書整合性は server 生成メタデータと fail-closed 検証を前提に扱う。
- health / readiness / reporting は匿名公開時も sanitize 済み情報だけを返し、接続先・資格情報・内部例外は構造化ログ側でも秘匿する。

## 注意
- health / readiness / liveness は匿名公開面で接続先・資格情報・内部例外を返さない。readiness は current contract として sanitized detailed checks を返す
- ORCA 接続先や credential は server 側で決定する
- クライアント入力の owner / facility / uri / digest を権威情報として扱わない
