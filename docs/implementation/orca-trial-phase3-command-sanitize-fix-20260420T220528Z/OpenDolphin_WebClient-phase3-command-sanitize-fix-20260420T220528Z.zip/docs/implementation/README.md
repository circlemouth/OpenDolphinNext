# Implementation

`docs/implementation/` は current implementation workstream の入口だけを置く領域です。ここには index を残し、current contract、live runbook、dated packet、evidence dump を混在させません。

## Current Workstreams
- [ORCA Trial Phase 3 command/sanitize fix 2026-04-20](orca-trial-phase3-command-sanitize-fix-20260420T220528Z/README.md)
- [ORCA Trial read-only contract fix Subagent A report 2026-04-20](orca-trial-readonly-contract-fix-20260420T000000Z/subagent-A-orca-wrapper-contract-report.md)
- [ORCA Trial read-only contract fix Subagent B report 2026-04-20](orca-trial-readonly-contract-fix-20260420T000000Z/subagent-B-readiness-classifier-report.md)
- [ORCA Trial read-only contract fix Subagent C report 2026-04-20](orca-trial-readonly-contract-fix-20260420T000000Z/subagent-C-local-selector-candidates-report.md)
- [ORCA Trial read-only contract fix Subagent D report 2026-04-20](orca-trial-readonly-contract-fix-20260420T000000Z/subagent-D-package-rerun-report.md)
- [ORCA Trial read-only diagnostics evidence rerun package 2026-04-20](orca-trial-readonly-diagnostics-20260420T000000Z/README.md)
- [ORCA Trial official patientgetv2 500 diagnostics 2026-04-20](orca-trial-readonly-diagnostics-20260420T000000Z/subagent-A-official-patientget-500-report.md)
- [ORCA Trial read-only preflight docs report 2026-04-20](orca-trial-readonly-preflight-harness-20260420T000000Z/subagent-C-docs-report.md)
- [ORCA Trial read-only preflight harness hardening 2026-04-19](orca-trial-readonly-preflight-harness-20260419T220346Z/README.md)
- [OpenDolphin dynamic-trial static remediation package 2026-04-18](opendolphin-dynamic-trial-static-remediation-package-20260418/README.md)
- [OpenDolphin postfix static remediation docset 2026-04-18](opendolphin-postfix-static-remediation-20260418/README.md)
- [OpenDolphin static fix package 2026-04-18](opendolphin-static-fix-package-20260418/README.md)
- [ORCA order alignment](orca-order-alignment/README.md)
- [OpenDolphin WebClient follow-up release gate package 2026-04-17](opendolphin-webclient-followup-release-gate-package-20260417/README.md)
- [OpenDolphin WebClient remaining follow-up package 2026-04-17](opendolphin-webclient-remaining-followup-package-20260417/README.md)
- [OpenDolphin WebClient 残ブロッカー解消 package 2026-04-17](opendolphin-webclient-implementation-package-20260417/README.md)
- [OpenDolphin WebClient implementation package 2026-04-16](opendolphin-webclient-implementation-package-20260416/README.md)

## Rules
- 契約の正本は `docs/contracts/` と `web-client/notes/` に置く
- 実行手順の正本は `docs/runbooks/` と `docs/releases/` に置く
- 背景資料は `docs/reference/` に置く
- dated packet / prompt / handoff / closeout / recovery / review template は `docs/archive/` に置く
- RUN_ID 固定の証跡は `artifacts/` に置き、`docs/` を evidence dump にしない
