# scripts/tools

## create-review-archive.sh
- 状態: deprecated。logs-only archive は reviewer submission packet の正本ではない。
- 挙動: 実行すると fail し、新しい packet tool へ誘導する。

## create-review-package.sh
- 位置づけ: support。canonical reviewer flow ではなく、tracked source を軽量 zip 化する補助用途。
- 目的: このリポジトリをレビュワー提出向けに 1 本の軽量 zip にまとめる。
- 出力: `artifacts/review-bundles/OpenDolphin_WebClient-review-package-<RUN_ID>.zip`
- Git 方針: 生成した reviewer ZIP と sidecar package artifact は外部提出物であり、`git add` / commit しない。永続化するのは package 生成・検証に必要な source / docs / scripts / skill の変更だけに限定する。
- 方針:
  - git tracked files を base とし、`--include-review-log-manifest` 指定時だけ manifest-listed evidence を追加する
  - `client/` と `artifacts/` を完全除外する
  - `node_modules/`, `dist/`, `target/`, `build/`, `out/`, `tmp/`, `output/`, `coverage/`, `test-results/` を除外する
  - nested zip はデフォルトで除外する。旧 `OpenDolphin_WebClient-review-package-*.zip` を `docs/implementation/` から再同梱しない
  - HAR、trace、video、raw screenshot、raw network dump、`network/`、`requests/`、`request-xml/`、`response-xml/` は package source から除外する
  - `REVIEW_PACKAGE_MANIFEST.txt` を zip 直下へ含める
  - `--include-review-log-manifest` 指定時のみ、manifest に列挙した sanitized review log / evidence contract を追加同梱する
  - `.git/` は含めず、clean checkout 証跡は主張しない
  - manifest と sidecar summary は `packageMode=extracted_review_subset`、`clean_checkout_claim=not_verified`、`worktree_clean=not_verified`、`full_source_secret_scan_claim=not_claimed` を明示する
  - sidecar summary は生成済み zip の `zip_file_count`、`zip_size_bytes`、`zip_sha256`、`source_commit`、`source_branch`、`git_claim_evidence_policy` を記録する
  - zip 内 manifest は self-referential hash drift を避けるため、zip integrity は `recorded_in_external_sidecar` として sidecar を参照する
  - dynamic evidence の secret scan は `dynamic_secret_scan_claim`、生成 review bundle 全体の source-scope scan は `package_source_secret_scan_claim` / `bundle_included_source_scope_secret_scan_claim`、full repo source scan は `full_source_secret_scan_claim` で分離する
  - `secret-scan-review-bundle.log` を含める場合は command log metadata、`exit_code=0`、`result=PASS`、`review bundle included source scope secret scan passed:` の出力が必要。揃わない場合は package 生成を fail する
  - command log は `command` / `cwd` / `runId` / `start` / `end` / `exit_code` に加えて non-empty command output を必須にする。無出力コマンドは wrapper が明示的な no-output marker を記録する
  - manifest-listed evidence は sanitized summaries / reports / command logs に限定し、raw ORCA artifact、nested zip、HAR、network/request/response、画像、trace/video、credential-bearing URL、Cookie、Authorization、JSESSIONID、CSRF、raw session、raw password を拒否する
  - nested zip inclusion が将来どうしても必要な場合は、明示 manifest・正当化理由・再帰 scan log を追加するまで許可しない
  - Phase 2.5 の `acceptedCandidateCount=0` は、`00001`〜`00011` について current harness / API / auth / parser / readiness / exact-preflight criteria の read-only evidence が mutation-ready まで揃っていない、という意味に限定する。公式初期患者が存在しない証明として扱わない
- 使い方:
  - `./scripts/create-review-package.sh`
  - `./scripts/create-review-package.sh --run-id 20260414T080812Z`
  - `./scripts/create-review-package.sh --run-id 20260414T080812Z --out-dir ./artifacts/review-bundles`
  - `./scripts/create-review-package.sh --run-id 20260418T224551Z --name-suffix -with-dynamic-evidence --include-review-log-manifest docs/implementation/opendolphin-postfix-static-remediation-20260418/REVIEW_LOG_INCLUSIONS_MANIFEST.txt`

## validate-review-package-metadata.mjs
- 位置づけ: support。`create-review-package.sh` が生成した zip と sidecar summary の metadata drift を検出する。
- 検証内容:
  - sidecar の `zip_file_count`、`zip_size_bytes`、`zip_sha256` が実 zip と一致する
  - `packageMode=extracted_review_subset`、`.git` 非同梱時の `worktree_clean=not_verified`、`full_source_secret_scan_claim=not_claimed` が維持される
  - `dynamic_secret_scan_claim`、`package_source_secret_scan_claim`、`bundle_included_source_scope_secret_scan_claim` が included log と矛盾しない
  - `secret-scan-review-bundle.log` がある場合、source-scope scan pass marker と command log success metadata が揃う
  - final ZIP source-scope secret scan log の `target_path` / `target_sha256` が final ZIP と一致する
  - command log の command output section が空なら fail する
  - raw/generated path、nested zip、credential-bearing URL、Cookie、Authorization、JSESSIONID、CSRF、raw password などを含む package を拒否する
- 使い方:
  - `node scripts/tools/validate-review-package-metadata.mjs artifacts/review-bundles/OpenDolphin_WebClient-review-package-<RUN_ID>.zip`
  - `node scripts/tools/validate-review-package-metadata.mjs <zip> <zip.summary.txt>`

## orca-readonly-evidence-finalizer.mjs
- 位置づけ: support。Phase 2.5 read-only rerun 後に、sanitized final summary / artifact hash / secret scan / package sidecar fields を固定する。
- 入力:
  - final review ZIP と `.summary.txt`
  - final ZIP source-scope secret scan command log
  - final ZIP metadata validation command log
  - `candidate-rows.sanitized.json`
  - `command-log.jsonl`
  - sanitized status JSON。少なくとも `sourceCommit` / `sourceCommitMatch`、`acceptedCandidateCount`、exact selected-candidate preflight status、Phase 3/4/fullflow/mutation/C7 status、`targetMutationRequestCount`、`checkedRequests`、official patientget status、insurance/appointment status and classification、selector/local/medical-information readiness、primary rejection reason、`rejectionReasons[]`、sanitize result、blocker dimensions、official patientget 500 / insurance 403 / appointment 403 classification を持つこと
- 出力:
  - `final-summary.sanitized.json`
  - `final-summary.sanitized.md`
  - `secret-scan.sanitized.txt`
  - `artifact-sha256.txt`
  - extracted `REVIEW_PACKAGE_MANIFEST.txt`
  - package sidecar `.summary.txt` への Phase 2.5 status field 追記
- 方針:
  - `full_source_secret_scan_claim=not_claimed` は、full source scan を実行していない限り維持する
  - `worktree_clean` は、package-included git command log がない限り `not_verified` のまま扱う
  - final ZIP の source-scope scan は final ZIP path と SHA-256 に bind されていることを検証する
  - final ZIP metadata validation log も final ZIP path と SHA-256 に bind されていることを検証する
  - dynamic evidence secret scan は current `RUN_ID` の evidence dir、candidate rows、command log JSONL、review log manifest だけを対象にする
  - raw ORCA body / raw patient detail / raw insurance detail / nested zip / HAR / trace / video / raw screenshot / raw network dump / credential / cookie / Authorization / JSESSIONID / CSRF / raw session / password / credential-bearing URL を reject する
- 使い方:
  - `node scripts/tools/orca-readonly-evidence-finalizer.mjs --run-id <RUN_ID> --evidence-dir docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID> --status-json docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/final-summary.status.sanitized.json --candidate-rows-json docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/candidate-rows.sanitized.json --command-log-jsonl docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/command-log.jsonl --package-zip docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/OpenDolphin_WebClient-review-package-<RUN_ID>-with-readonly-diagnostics.zip --package-summary docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/OpenDolphin_WebClient-review-package-<RUN_ID>-with-readonly-diagnostics.zip.summary.txt --package-secret-scan-log docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/OpenDolphin_WebClient-review-package-<RUN_ID>-with-readonly-diagnostics.zip.secret-scan-review-bundle.log --metadata-validation-log docs/implementation/orca-trial-readonly-diagnostics-<RUN_ID>/final-package-metadata-validation.log`

## create-review-package-curated.sh
- 位置づけ: support。50MB 制約つきの curated review bundle。
- 目的: current docs / workflow docs / current source / selected doc-reorg reports を含めつつ、legacy tree と大きい非必須 binary を落としてレビュー zip を 50MB 以内に収める。
- 出力: `artifacts/review-bundles/OpenDolphin_WebClient-review-package-curated-<RUN_ID>.zip`
- 方針:
  - current docs と active workflow docs を含める
  - `artifacts/doc-reorg/` の text/log reports を再同梱する
  - reviewer 指定の archive / repository-history 資料は個別 allowlist で常時含める
  - `client/`, `server/`, `ext_lib/`, `docker/orca/jma-receipt-docker/` を除外する
  - `docs/archive/` はデフォルトで除外し、必要時だけ `--include-archive-docs` で含める
  - `ops/assets/fonts/NotoSansCJKjp-Regular.otf` など大きい review-irrelevant binary を除外する
  - zip size が `--size-limit-mb` を超えたら fail する
- 使い方:
  - `./scripts/create-review-package-curated.sh`
  - `./scripts/create-review-package-curated.sh --run-id 20260415T010203Z`
  - `./scripts/create-review-package-curated.sh --run-id 20260415T010203Z --size-limit-mb 50`
  - `./scripts/create-review-package-curated.sh --run-id 20260415T010203Z --include-archive-docs`

## create-reviewer-submission-packet.sh
- 位置づけ: canonical。reviewer 提出の現行正本フロー。
- 目的: accepted ref / accepted HEAD / RUN_ID を固定した reviewer submission packet を生成する。
- 出力: `submission-packet-<RUN_ID>/` と `submission-packet-<RUN_ID>.zip`。
- レイアウト:
  - `review-checkout/`: `.git` と `origin/master` を持つ clean checkout
  - `closeout-packet/`: 同一 RUN_ID / 同一 HEAD の closeout evidence
  - `manifest.json`, `manifest.sha256`, `README_REVIEW.md`
- 使い方:
  - `./scripts/create-reviewer-submission-packet.sh --run-id 20260414T010624Z --accepted-ref codex/orca-closeout-recovery-20260414T010624Z`
  - `./scripts/create-reviewer-submission-packet.sh --run-id 20260414T010624Z --accepted-ref codex/orca-closeout-recovery-20260414T010624Z --output ./artifacts/reviewer-submission-packets`
  - `./scripts/create-reviewer-submission-packet.sh --run-id 20260414T010624Z --accepted-ref codex/orca-closeout-recovery-20260414T010624Z --dry-run`
- Evidence policy:
  - closeout evidence から reviewer 再読用の extracted subset だけを同梱する
  - exact selected-candidate `qa/weborca-readonly-preflight/summary.json` だけを Phase 3 handoff artifact として扱う
  - candidate discovery は sanitized proposal であり、Phase 3 許可や live success の根拠にしない
  - accepted candidate 0 件は公式初期患者 `00001`〜`00011` の不在ではなく、`PARTIAL / TEST-DATA OR HARNESS READINESS BLOCKER` として扱う
  - credential-bearing URL、Cookie、Authorization、JSESSIONID、CSRF、raw password、患者機微 detail を packet に含めない

## validate-reviewer-submission-packet.sh
- 位置づけ: canonical support。reviewer submission packet の検証ステップ。
- 目的: 生成済み packet の required file、HEAD 一致、review-checkout clean、絶対パス混入なしを再検証する。
- 使い方:
  - `./scripts/validate-reviewer-submission-packet.sh --run-id 20260414T010624Z --accepted-ref codex/orca-closeout-recovery-20260414T010624Z`
  - `./scripts/validate-reviewer-submission-packet.sh --run-id 20260414T010624Z --accepted-ref codex/orca-closeout-recovery-20260414T010624Z --output ./artifacts/reviewer-submission-packets`

## orca-artifacts-namer.js
- 目的: `artifacts/orca-connectivity/` 以下の Evidence ディレクトリ名が UTC タイムスタンプ (`YYYYMMDDThhmmssZ`) に統一されているかを自動検証し、命名揺れがある場合は推奨名を提案する。
- 事前条件: Node.js が利用可能であること。Python 実行は禁止されているため、必ず `node` コマンドで実行する。
- 使い方:
  - リポジトリルートで `node scripts/tools/orca-artifacts-namer.js` を実行すると、デフォルトで `artifacts/orca-connectivity/` を走査する。
  - 任意のパスを渡す場合は `node scripts/tools/orca-artifacts-namer.js <path/to/scan>`。
- 終了コード: 命名がすべて規約通りであれば 0。規約違反があると違反一覧と推奨名を表示して 1 を返す。実行エラー時も 1。

## web-client/scripts/qa-phase3-approved-acceptmodv2.mjs
- 位置づけ: Phase 3 command/sanitize remediation の承認済み入口。Phase 3 本番実行そのものではなく、exact preflight gate と sanitized-only artifact contract を固定する。
- 目的: `qa-acceptmodv2-weborca.mjs` を直接実行せず、candidate `00001`、exact selected-candidate preflight path/hash/input identity、Phase 3 only、no browser/network artifact を fail-closed で検証してから future Phase 3 owner だけが受付登録 mutation へ進めるようにする。
- 固定入力:
  - candidate / patient: `00001`
  - preflight: `docs/implementation/orca-trial-readonly-contract-fix-20260420T141516Z/exact-selected-candidate-preflight.sanitized.json`
  - preflight sha256: `57d43788d7384cdcdc6368271bbcfdf1a2f1a87e92c6ee801271c36332159590`
  - input identity hash: `356d109381b57e0c792eada1a4bd394248c6fca8273a82ab770143efc92bc29a`
- 必須 mode flags:
  - `--sanitized-evidence-only`
  - `--disable-browser-artifacts`
  - `--phase3-only`
  - ちょうど 1 つだけ: `--dry-run`, `--mock`, `--execute-approved-mutation`
- 禁止:
  - Phase 4 / fullflow / direct curl / other candidate flags
  - HAR / trace / video / screenshot / raw network artifact flags
  - `QA_RECORD_HAR=1`, raw network capture env, Phase 4/fullflow env, local option injection env
- dry-run:
```bash
node web-client/scripts/qa-phase3-approved-acceptmodv2.mjs \
  --candidate 00001 \
  --preflight docs/implementation/orca-trial-readonly-contract-fix-20260420T141516Z/exact-selected-candidate-preflight.sanitized.json \
  --preflight-sha256 57d43788d7384cdcdc6368271bbcfdf1a2f1a87e92c6ee801271c36332159590 \
  --input-identity-sha256 356d109381b57e0c792eada1a4bd394248c6fca8273a82ab770143efc92bc29a \
  --sanitized-evidence-only \
  --disable-browser-artifacts \
  --phase3-only \
  --dry-run
```
- future Phase 3 owner 用の実行形は、ChatGPT が remediation package を accept した後に限り `--dry-run` を `--execute-approved-mutation` に置き換える。Phase 4 と fullflow は引き続き実行しない。
- 出力:
  - dry-run/mock: `phase3-approved-command.sanitized.json` のみ。ORCA 接続、mutation route、browser artifacts、network directory は生成しない。
  - execute-approved-mutation: `qa-acceptmodv2-weborca.mjs` を `QA_PHASE3_APPROVED_MODE=1` / `QA_SANITIZED_EVIDENCE_ONLY=1` / `QA_DISABLE_BROWSER_ARTIFACTS=1` で呼び出し、raw summary、network directory、screenshots、HAR を生成しない。

## Naming Rule
- 現行正本名は `reviewer submission packet`。
- `review package` は support bundle。
- `review archive` は deprecated。
