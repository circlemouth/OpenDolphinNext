import { describe, expect, it } from 'vitest';

import {
  CANDIDATE_DISCOVERY_SOURCE,
  EXACT_PREFLIGHT_FLOW_MODE,
  EXACT_PREFLIGHT_KIND,
  EXACT_PREFLIGHT_SOURCE,
  SELECTOR_OPTION_MISSING_BLOCKER,
  buildInputIdentity,
  resolveSelectableOption,
  validatePreflightSummary,
} from '../qa-lib/acceptmodv2-identity-gate.mjs';

const baseInput = {
  runId: '20260419T013630Z',
  candidateId: '20260419T013630Z:acceptmodv2',
  facilityId: 'FACILITY-1',
  patientId: '0000001',
  departmentCode: '01',
  physicianCode: '10001',
  paymentMode: 'insurance',
  visitKind: '1',
  medicalInformation: '',
};

const acceptedSummary = (overrides = {}) => {
  const input = { ...baseInput, ...overrides };
  const medicalInformationState = input.medicalInformation
    ? { state: 'selected', value: input.medicalInformation }
    : { state: 'omitted' };
  return {
    runId: input.runId,
    source: EXACT_PREFLIGHT_SOURCE,
    flowMode: EXACT_PREFLIGHT_FLOW_MODE,
    kind: EXACT_PREFLIGHT_KIND,
    candidateId: input.candidateId,
    verdict: 'accepted',
    blockerClassification: 'none',
    acceptedForPhase3Attempt: true,
    facilityId: input.facilityId,
    patientId: input.patientId,
    phase3AttemptPatientId: input.patientId,
    departmentCode: input.departmentCode,
    physicianCode: input.physicianCode,
    paymentMode: input.paymentMode,
    visitKind: input.visitKind,
    medicalInformation: input.medicalInformation || undefined,
    medicalInformationState,
    inputIdentity: buildInputIdentity(input),
    officialPatientEvidenceRef: 'summary.json#/officialPatientExistence',
    officialPatientEvidenceHash: 'official-hash',
    insuranceEvidenceRef: 'summary.json#/insuranceReadiness',
    insuranceEvidenceHash: 'insurance-hash',
    localSelectableEvidenceRef: 'summary.json#/localSelectableReadiness',
    localSelectableEvidenceHash: 'local-hash',
    selectorEvidenceRef: 'summary.json#/selectorReadiness',
    selectorEvidenceHash: 'selector-hash',
    officialPatientExistence: {
      httpStatus: 200,
      parsedOrcaBody: true,
      apiResult: '00',
      apiResultAccepted: true,
      patientInformationPresent: true,
      exactIdMatched: true,
      notFoundMessage: false,
      responseCategory: 'present',
      rejectionReason: 'none',
      evidenceHash: 'official-hash',
      rawSensitiveFieldsExcluded: true,
    },
    insuranceReadiness: {
      verdict: 'accepted',
      accepted: true,
      classification: 'accepted',
      count: 1,
      effectiveCount: 1,
    },
    selectorReadiness: {
      verdict: 'accepted',
      accepted: true,
      details: {},
    },
    medicalInformationReadiness: {
      verdict: 'accepted',
      accepted: true,
      reason: 'none',
      failedSubdimensions: [],
      dimensions: {
        department_ready: { ready: true, reason: 'none' },
        physician_ready: { ready: true, reason: 'none' },
        payment_ready: { ready: true, reason: 'none' },
        visitKind_ready: { ready: true, reason: 'none' },
        medicalInformation_input_ready: { ready: true, reason: 'none' },
        medicalInformation_omitted_state_matches: { ready: true, reason: 'none' },
        required_identity_fields_match: { ready: true, reason: 'none' },
      },
    },
    localSelectableReadiness: {
      verdict: 'accepted',
      accepted: true,
      exactMatchCount: 1,
      recordsReturned: 1,
    },
    appointmentDependency: {
      flowMode: 'direct_acceptance',
      required: false,
      absenceBlocker: false,
      verdict: 'accepted',
      accepted: true,
      classification: 'direct_acceptance_no_appointment_required',
    },
    acceptmodv2ReadOnlyDiagnostic: {
      apiResult: '60',
      classification: 'diagnostic_no_existing_acceptance',
      businessStatus: 'diagnosticNoExistingAcceptance',
      businessReason: 'no_existing_acceptance',
      accepted: true,
      mutationSuccess: false,
      acceptedForPhase3Attempt: true,
    },
    mutationPolicy: {
      prohibited: true,
      blockedRequestCount: 0,
      blockedRequests: [],
      targetMutationRequestCount: 0,
    },
    rawSensitiveFieldsExcluded: true,
  };
};

describe('acceptmodv2 preflight identity gate', () => {
  it('current exact selected-candidate shape proceeds without stale candidates map', () => {
    const summary = acceptedSummary();
    expect(summary.officialPatientExistence).not.toHaveProperty('candidates');

    const result = validatePreflightSummary({
      summary,
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(true);
    expect(result.mutationAllowed).toBe(true);
    expect(result.blockerClassification).toBe('none');
  });

  it('rejects artifact hash mismatch when a pinned hash is provided', () => {
    const result = validatePreflightSummary({
      summary: acceptedSummary(),
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expectedArtifactSha256: 'def456',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.error).toContain('hash mismatch');
  });

  it('rejects exact preflight input identity hash mismatch when a pinned hash is provided', () => {
    const result = validatePreflightSummary({
      summary: acceptedSummary(),
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expectedInputIdentitySha256: 'wrong-hash',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_input_mismatch');
    expect(result.mismatches.map((item) => item.field)).toContain('inputIdentity.hash');
  });

  it('rejects exact preflight when targetMutationRequestCount is not zero', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        mutationPolicy: {
          prohibited: true,
          blockedRequestCount: 0,
          blockedRequests: [],
          targetMutationRequestCount: 1,
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_target_mutation_count_nonzero');
  });

  it.each([
    ['runId', { runId: '20260419T999999Z' }, 'runId'],
    ['candidate', { candidateId: 'other-candidate' }, 'candidate.candidateId'],
    ['patient', { patientId: '9999999' }, 'input.patientId'],
    ['department', { departmentCode: '02' }, 'input.departmentCode'],
    ['physician', { physicianCode: '20002' }, 'input.physicianCode'],
    ['payment', { paymentMode: 'self-pay' }, 'input.paymentMode'],
    ['visitKind', { visitKind: '2' }, 'input.visitKind'],
    ['medicalInformation selected value', { medicalInformation: '01' }, 'input.medicalInformation'],
  ])('%s mismatch fails closed before mutation', (_label, expectedOverride, mismatchField) => {
    const result = validatePreflightSummary({
      summary: acceptedSummary(),
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: { ...baseInput, ...expectedOverride },
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_input_mismatch');
    expect(result.mismatches.map((item) => item.field)).toContain(mismatchField);
  });

  it('rejects candidate discovery summary even when it proposes a selected candidate', () => {
    const result = validatePreflightSummary({
      summary: {
        runId: baseInput.runId,
        source: CANDIDATE_DISCOVERY_SOURCE,
        flowMode: 'candidate-discovery-proposal',
        candidateDiscoveryAloneAuthorizesPhase3: false,
        acceptedForPhase3Attempt: false,
        selectedCandidate: { kind: 'proposal', patientId: baseInput.patientId },
      },
      artifactPath: '/tmp/discovery-summary.json',
      artifactSha256: 'def456',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('candidate_discovery_only');
  });

  it('rejects candidate discovery summary even if it claims acceptedForPhase3Attempt=true', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        source: CANDIDATE_DISCOVERY_SOURCE,
        flowMode: 'candidate-discovery-proposal',
        candidateDiscoveryAloneAuthorizesPhase3: false,
        acceptedForPhase3Attempt: true,
      },
      artifactPath: '/tmp/discovery-summary.json',
      artifactSha256: 'def456',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('candidate_discovery_only');
  });

  it('does not reject exact preflight solely because it carries candidate discovery safety metadata', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        source: EXACT_PREFLIGHT_SOURCE,
        flowMode: EXACT_PREFLIGHT_FLOW_MODE,
        candidateDiscoveryAloneAuthorizesPhase3: false,
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(true);
    expect(result.mutationAllowed).toBe(true);
    expect(result.blockerClassification).toBe('none');
  });

  it('rejects direct acceptance preflight when an appointment blocker is present', () => {
    const summary = acceptedSummary();
    const result = validatePreflightSummary({
      summary: {
        ...summary,
        appointmentDependency: {
          ...summary.appointmentDependency,
          absenceBlocker: true,
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_phase3_not_accepted');
    expect(result.phase3ReadinessFailures).toContain('appointmentDependency');
  });

  it.each([
    ['false', false],
    ['string true', 'true'],
    ['number 1', 1],
    ['object', { patientId: baseInput.patientId }],
    ['null', null],
  ])('rejects non-boolean true acceptedForPhase3Attempt value: %s', (_label, acceptedForPhase3Attempt) => {
    const result = validatePreflightSummary({
      summary: { ...acceptedSummary(), acceptedForPhase3Attempt },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_not_accepted');
  });

  it('rejects exact preflight when inputIdentity is missing', () => {
    const summary = acceptedSummary();
    delete (summary as Record<string, unknown>).inputIdentity;
    const result = validatePreflightSummary({
      summary,
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.missingFields).toContain('inputIdentity');
  });

  it('rejects exact preflight when diagnostic is missing', () => {
    const summary = acceptedSummary();
    delete (summary as Record<string, unknown>).acceptmodv2ReadOnlyDiagnostic;
    const result = validatePreflightSummary({
      summary,
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.missingFields).toContain('acceptmodv2ReadOnlyDiagnostic');
  });

  it.each(['departmentCode', 'physicianCode', 'paymentMode', 'visitKind'])(
    'rejects exact preflight when required identity field %s is missing',
    (field) => {
      const summary = acceptedSummary();
      delete (summary as Record<string, unknown>)[field];
      const result = validatePreflightSummary({
        summary,
        artifactPath: '/tmp/summary.json',
        artifactSha256: 'abc123',
        expected: baseInput,
      });

      expect(result.ok).toBe(false);
      expect(result.blockerClassification).toBe('preflight_artifact_invalid');
      expect(result.missingFields).toContain(field);
    },
  );

  it('rejects exact preflight when raw sensitive field exclusion is not asserted', () => {
    const result = validatePreflightSummary({
      summary: { ...acceptedSummary(), rawSensitiveFieldsExcluded: false },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.missingFields).toContain('rawSensitiveFieldsExcluded');
  });

  it('rejects exact preflight when medicalInformationReadiness is missing', () => {
    const summary = acceptedSummary();
    delete (summary as Record<string, unknown>).medicalInformationReadiness;
    const result = validatePreflightSummary({
      summary,
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.missingFields).toContain('medicalInformationReadiness');
  });

  it('rejects exact preflight when medicalInformation readiness subdimensions are not accepted', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        medicalInformationReadiness: {
          verdict: 'rejected',
          accepted: false,
          reason: 'medical_information_not_ready',
          failedSubdimensions: ['department_ready'],
          dimensions: {
            department_ready: { ready: false, reason: 'selector_exact_match_missing' },
          },
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_phase3_not_accepted');
    expect(result.phase3ReadinessFailures).toContain('medicalInformationReadiness');
  });

  it('requires official, insurance, appointment, local, selector, and identity dimensions to all be accepted', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        officialPatientExistence: {
          httpStatus: 200,
          parsedOrcaBody: true,
          apiResult: '00',
          apiResultAccepted: true,
          patientInformationPresent: true,
          exactIdMatched: false,
          notFoundMessage: false,
          responseCategory: 'different_patient_id_present',
          rejectionReason: 'exact_patient_id_mismatch',
          rawSensitiveFieldsExcluded: true,
        },
        insuranceReadiness: {
          verdict: 'rejected',
          accepted: false,
          classification: 'business_rejected_insurance',
        },
        appointmentDependency: {
          flowMode: 'appointment_row',
          required: true,
          absenceBlocker: true,
          verdict: 'rejected',
          accepted: false,
          classification: 'appointment_row_missing',
        },
        localSelectableReadiness: {
          verdict: 'rejected',
          accepted: false,
          reason: 'local_exact_match_missing',
          exactMatchCount: 0,
        },
        selectorReadiness: {
          verdict: 'not_verified',
          accepted: false,
          reason: 'local_exact_match_missing',
        },
        medicalInformationReadiness: {
          verdict: 'rejected',
          accepted: false,
          reason: 'medical_information_not_ready',
          failedSubdimensions: ['required_identity_fields_match'],
          dimensions: {
            required_identity_fields_match: { ready: false, reason: 'required_identity_fields_missing_or_unmatched' },
          },
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_phase3_not_accepted');
    expect(result.phase3ReadinessFailures).toEqual(
      expect.arrayContaining([
        'officialPatientExistence',
        'insuranceReadiness',
        'appointmentDependency',
        'localSelectableReadiness',
        'selectorReadiness',
        'medicalInformationReadiness',
      ]),
    );
  });

  it('rejects exact preflight when Request_Number=00 found an existing acceptance', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        acceptmodv2ReadOnlyDiagnostic: {
          apiResult: '00',
          classification: 'diagnostic_existing_acceptance',
          businessStatus: 'diagnosticExistingAcceptance',
          businessReason: 'existing_acceptance',
          mutationSuccess: false,
          acceptedForPhase3Attempt: false,
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_diagnostic_not_verified');
  });

  it('accepts exact preflight when acceptmod diagnostic is intentionally not run by read-only policy', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        acceptmodv2ReadOnlyDiagnostic: {
          apiResult: '',
          status: 'not_run',
          verdict: 'accepted',
          businessStatus: 'notRun',
          businessReason: 'mutation_route_not_called_by_policy',
          accepted: true,
          mutationSuccess: false,
          classification: 'mutation_diagnostic_not_run_by_policy',
          acceptedForPhase3Attempt: true,
          routeCalled: false,
          rawSensitiveFieldsExcluded: true,
        },
        mutationPolicy: {
          prohibited: true,
          blockedRequestCount: 0,
          blockedRequests: [],
          targetMutationRequestCount: 0,
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(true);
    expect(result.mutationAllowed).toBe(true);
    expect(result.blockerClassification).toBe('none');
  });

  it('rejects read-only not-run diagnostic when mutation policy evidence is missing', () => {
    const summary = {
      ...acceptedSummary(),
      acceptmodv2ReadOnlyDiagnostic: {
        apiResult: '',
        status: 'not_run',
        verdict: 'accepted',
        businessStatus: 'notRun',
        businessReason: 'mutation_route_not_called_by_policy',
        accepted: true,
        mutationSuccess: false,
        classification: 'mutation_diagnostic_not_run_by_policy',
        acceptedForPhase3Attempt: true,
        routeCalled: false,
        rawSensitiveFieldsExcluded: true,
      },
    };
    delete (summary as Record<string, unknown>).mutationPolicy;

    const result = validatePreflightSummary({
      summary,
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_diagnostic_not_verified');
    expect(result.error).toContain('mutation_policy_missing');
  });

  it('rejects read-only not-run diagnostic when target mutation request count is nonzero', () => {
    const result = validatePreflightSummary({
      summary: {
        ...acceptedSummary(),
        acceptmodv2ReadOnlyDiagnostic: {
          apiResult: '',
          status: 'not_run',
          verdict: 'accepted',
          businessStatus: 'notRun',
          businessReason: 'mutation_route_not_called_by_policy',
          accepted: true,
          mutationSuccess: false,
          classification: 'mutation_diagnostic_not_run_by_policy',
          acceptedForPhase3Attempt: true,
          routeCalled: false,
          rawSensitiveFieldsExcluded: true,
        },
        mutationPolicy: {
          prohibited: true,
          blockedRequestCount: 0,
          blockedRequests: [],
          targetMutationRequestCount: 1,
        },
      },
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_diagnostic_not_verified');
    expect(result.error).toContain('target_mutation_request_count_nonzero');
  });

  it('requires exact preflight artifact path and hash', () => {
    const result = validatePreflightSummary({
      summary: acceptedSummary(),
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.blockerClassification).toBe('preflight_artifact_invalid');
    expect(result.missingFields).toEqual(['artifactPath', 'artifactSha256']);
  });

  it('rejects selected preflight when current run omits medicalInformation', () => {
    const result = validatePreflightSummary({
      summary: acceptedSummary({ medicalInformation: '01' }),
      artifactPath: '/tmp/summary.json',
      artifactSha256: 'abc123',
      expected: baseInput,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.blockerClassification).toBe('preflight_input_mismatch');
    expect(result.mismatches.map((item) => item.field)).toContain('summary.medicalInformationState');
    expect(result.mismatches.map((item) => item.field)).toContain('input.medicalInformation');
  });
});

describe('acceptmodv2 selector gate', () => {
  it('live option missing blocks mutation and does not inject', () => {
    const result = resolveSelectableOption({
      field: 'departmentCode',
      desiredValue: '01',
      options: ['02', '03'],
      allowLocalOptionInjection: false,
    });

    expect(result.ok).toBe(false);
    expect(result.mutationAllowed).toBe(false);
    expect(result.injected).toBe(false);
    expect(result.blockerClassification).toBe(SELECTOR_OPTION_MISSING_BLOCKER);
  });

  it('local permissive injection is explicit and not accepted as live evidence', () => {
    const result = resolveSelectableOption({
      field: 'departmentCode',
      desiredValue: '01',
      options: ['02', '03'],
      allowLocalOptionInjection: true,
    });

    expect(result.ok).toBe(true);
    expect(result.mutationAllowed).toBe(true);
    expect(result.injected).toBe(true);
    expect(result.acceptedLiveEvidence).toBe(false);
  });
});
